#### Version 2.0.3 - 2016/08/10
* added setting to declare a set tooltip width
* updated hint.css library to current version

#### Version 2.0.2 - 2016/05/27
* added ability to include tooltips on section blocks
* moved `gf_tooltips_allowed_fields` filter from `admin.php` file to `helper.php` file to allow checks on front end
* minor cleanup

#### Version 2.0.1 - 2016/01/26
* added GitHub Updater support
* cleaned up for coding standards

#### Version 2.0.0 - 2015/07/19
* total overhaul. removed JS requirements, added hint.css library
